import React from 'react';
import { Text, View } from 'react-native';
import { createBottomTabNavigator } from 'react-navigation';
import { dynamicSize } from '../../utils/responsive';

class HomeScreen extends React.Component {
    render() {
        return (
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                <Text>Dashboard!</Text>
            </View>
        );
    }
}

class Storecard extends React.Component {
    render() {
        return (
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                <Text>Store Cards!</Text>
            </View>
        );
    }
}
class Scan extends React.Component {
    render() {
        return (
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                <Text>Scan</Text>
            </View>
        );
    }
}
class MarketPlace extends React.Component {
    render() {
        return (
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                <Text>Market Place!</Text>
            </View>
        );
    }
}
class Community extends React.Component {
    render() {
        return (
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                <Text>Community!</Text>
            </View>
        );
    }
}


export default createBottomTabNavigator({
    Dashboard: HomeScreen,
    StoreCard: Storecard,
    Scan:Scan,
    MarketPlace:MarketPlace,
    Community:Community

},
    {
        tabBarOptions: {
            labelStyle: {
                fontSize: 12,
            },
            tabStyle: {
                // width: 100,
            },
            style: {
                // backgroundColor: 'blue',
                paddingBottom:dynamicSize(7),
                height:dynamicSize(45)
            },
        }
    }
);