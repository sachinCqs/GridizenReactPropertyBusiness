import React, { Component } from 'react';
import { View, Text, StyleSheet, TextInput, Image, ScrollView, TouchableOpacity, Alert, TouchableWithoutFeedback } from 'react-native';
import { dynamicSize, getFontSize, fontFamily } from '../../utils/responsive';
import DateTimePicker from 'react-native-modal-datetime-picker';

// var dynamicSize = (size) => { return size };
// var getFontSize = (size) => { return size };
// var fontFamily = () => { };

export default class Adddeal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            communityTitle: '',
            communityDescription: '',
            dealPrice: "",
            totalSale: '',
            validity: '',
            startDate: '',
            endDate: '',
            datePickerVisible: false,
            date: [],
            check: ''
        };
    }

    componentWillMount() {
        var arr = [
            {
                id: 1,
                value: "arpit"
            },
            {
                id: 2,
                value: "rama"
            },
            {
                id: 1,
                value: "kaushik"
            },
            {
                id: 2,
                value: "ghanshayma"
            }
        ]


        var result = [];
        var temp = [];
        for (let i = 0; i < arr.length; i++) {
            for (let j = i; j < arr.length; j++) {
                if (i != j) {
                    if (arr[i].id == arr[j].id) {
                        temp.push(arr[i]),
                            temp.push(arr[j])
                    }
                }
            }
            result.push(temp)
            temp = []
        }
        console.log("--->>>" + JSON.stringify(result))
    }

    // handle text input
    onChange(text, type) {
        //this pattern checks for emoji
        var pattern = /(?:[\u2700-\u27bf]|(?:\ud83c[\udde6-\uddff]){2}|[\ud800-\udbff][\udc00-\udfff])[\ufe0e\ufe0f]?(?:[\u0300-\u036f\ufe20-\ufe23\u20d0-\u20f0]|\ud83c[\udffb-\udfff])?(?:\u200d(?:[^\ud800-\udfff]|(?:\ud83c[\udde6-\uddff]){2}|[\ud800-\udbff][\udc00-\udfff])[\ufe0e\ufe0f]?(?:[\u0300-\u036f\ufe20-\ufe23\u20d0-\u20f0]|\ud83c[\udffb-\udfff])?)*/
        if (type === 'communityTitle') {
            if (!pattern.test(text)) {
                this.setState({
                    communityTitle: text.replace(/[^A-Za-z ]/g, ''),
                });
            }
        }
        if (type === 'communityDescription') {
            if (!pattern.test(text)) {
                this.setState({
                    communityDescription: text.replace(/[^A-Za-z0-9 ]/g, ''),
                });
            }
        }
        if (type == "dealPrice") {
            if (!pattern.test(text)) {
                this.setState({
                    dealPrice: text.replace(/[^A-Za-z ]/g, ''),
                });
            }
        }
        if (type == "totalsale") {
            if (!pattern.test(text)) {
                this.setState({
                    totalSale: text
                });
            }
        }
        if (type == "validity") {
            if (!pattern.test(text)) {
                this.setState({
                    validity: text
                });
            }
        }
    }
    ShowAlert() {
        Alert.alert(
            'Alert Title',
            'Successful',
            [
                { text: 'Ok', onPress: () => (''), style: 'Ok' }
            ],
            { Ok: false }

        )
    }

    _publish() {
        alert("publish")
    }

    _saveDraft() {
        alert("draft")

    }

    _openCalender(check) {
        this.setState({ check: check })
        if (check == "end" && this.state.date.length == 0) {
            alert("Please select start date.")
        }
        else {
            this.setState({ datePickerVisible: true })
        }
    }

    _handleDatePicked(date) {
        this.setState({
            datePickerVisible: false
        })
        let data = this.state.date;
        let d = new Date(date)
        let Year = d.getFullYear();
        let Month = d.getMonth();
        let MonthString = (d.getMonth() + 1) < 10 ? '0' + (d.getMonth() + 1) : (d.getMonth() + 1);
        let Day = (d.getDate()) < 10 ? '0' + (d.getDate()) : (d.getDate());
        if (data.length != 2) {
            data.push(Year + "-" + MonthString + "-" + Day)
        }
        else {
            if (this.state.check == "start") {
                data[0] = Year + "-" + MonthString + "-" + Day
            }
            else {
                data[1] = Year + "-" + MonthString + "-" + Day
            }
        }
        this.setState({ date: data, startDate: data[0], endDate: data[1] ? data[1] : '' })
        console.log(this.state.date)
    }

    render() {
        return (
            <ScrollView style={styles.Container} >
                <DateTimePicker
                    isVisible={this.state.datePickerVisible}
                    onConfirm={(date) => this._handleDatePicked(date)}
                    onCancel={() => this.setState({ datePickerVisible: false })}
                    mode="date"
                    maximumDate={new Date()}
                    is24Hour={false}
                //datePickerContainerStyleIOS={styles.datepickeriosstyle}
                />
                <View style={styles.uploadPic}>
                    <TouchableOpacity>
                        <Image style={{ width: dynamicSize(40), height: dynamicSize(40) }} source={require('../../assets/camera.png')} />
                    </TouchableOpacity>
                    <Text style={{ color: '#838383', fontSize: getFontSize(14), fontFamily: fontFamily(), marginTop: dynamicSize(6) }} >Deals Image</Text>
                </View>
                <TextInput
                    style={styles.txtinput}
                    placeholder='Name'
                    placeholderTextColor='#838383'
                    keyboardType={"default"}
                    maxLength={20}
                    onChangeText={(text) => this.onChange(text, "communityTitle")}
                    value={this.state.communityTitle}
                    onSubmitEditing={() => this.refs.dealDetail.focus()}
                    maxLength={40}

                />
                <TextInput
                    style={styles.txtinput}
                    placeholder='Detail'
                    placeholderTextColor='#838383'
                    keyboardType={"default"}
                    maxLength={100}
                    onChangeText={(text) => this.onChange(text, "communityDescription")}
                    value={this.state.communityDescription}
                    ref="dealDetail"
                    maxLength={100}
                    multiline={true}
                    onSubmitEditing={() => this.refs.dealPrice.focus()}
                />

                <TextInput
                    style={styles.txtinput}
                    placeholder='Price'
                    placeholderTextColor='#838383'
                    keyboardType={"default"}
                    maxLength={100}
                    onChangeText={(text) => this.onChange(text, "dealPrice")}
                    value={this.state.dealPrice}
                    ref="dealPrice"
                    onSubmitEditing={() => this._openCalender()}
                    maxLength={6}
                />

                <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
                    <TouchableOpacity style={{ flex: 1 }} onPress={() => this._openCalender("start")}>
                        <TextInput
                            style={[styles.txtinput, { marginRight: dynamicSize(8) }]}
                            placeholder='Start date'
                            placeholderTextColor='#838383'
                            keyboardType={"default"}
                            // onChangeText={(text) => this.onChange(text, "dealPrice")}
                            value={this.state.startDate}
                            editable={false}
                        />
                    </TouchableOpacity>

                    <TouchableOpacity style={{ flex: 1 }} onPress={() => this._openCalender("end")}>
                        <TextInput
                            style={[styles.txtinput, { marginLeft: dynamicSize(8) }]}
                            placeholder='End date'
                            placeholderTextColor='#838383'
                            keyboardType={"default"}
                            // onChangeText={(text) => this.onChange(text, "dealPrice")}
                            value={this.state.endDate}
                            editable={false}
                        />
                    </TouchableOpacity>
                </View>
                <TextInput
                    style={styles.txtinput}
                    placeholder='Total no for sale'
                    placeholderTextColor='#838383'
                    keyboardType={"default"}
                    maxLength={100}
                    onChangeText={(text) => this.onChange(text, "totalsale")}
                    value={this.state.totalSale}
                    keyboardType="numeric"
                    onSubmitEditing={() => this.refs.validity.focus()}
                    maxLength={6}
                />

                <TextInput
                    style={styles.txtinput}
                    placeholder='Validity'
                    placeholderTextColor='#838383'
                    keyboardType={"default"}
                    maxLength={100}
                    onChangeText={(text) => this.onChange(text, "validity")}
                    value={this.state.validity}
                    keyboardType="numeric"
                    ref="validity"
                    maxLength={6}


                />



                {/* <TouchableOpacity
                    style={styles.buttonView}
                    onPress={() => this.ShowAlert()}

                >

                    <Text style={{ color: '#fff', fontFamily: fontFamily(), fontSize: getFontSize(18), fontWeight: '500' }}><Image style={{ width: dynamicSize(20), height: dynamicSize(20) }} source={require('../asset/check.png')} />  Save</Text>
                </TouchableOpacity> */}
                <View style={[styles.accomodationView, { marginBottom: dynamicSize(20) }]}>
                    <TouchableOpacity onPress={() => this._saveDraft()} style={{ flex: 1, paddingVertical: dynamicSize(12), alignItems: 'center', justifyContent: 'center', borderWidth: 0.5, borderColor: '#A2A8A2', backgroundColor: '#F49930' }}
                    >
                        <Text style={[styles.boldText, { color: 'white' }]}>Save drafts</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={{ flex: 1, paddingVertical: dynamicSize(12), alignItems: 'center', justifyContent: 'center', borderWidth: 0.5, borderColor: '#A2A8A2' }}
                        onPress={() => this._publish()} >
                        <Text style={styles.boldText}>Publish</Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
        );
    }
}
const styles = StyleSheet.create({
    Container: {
        flex: 1,
        backgroundColor: "white",
        padding: dynamicSize(15)
    },

    txtinput: {
        //flex:1,
        color: '#838383',
        paddingVertical: dynamicSize(8),
        marginBottom: dynamicSize(10),
        marginTop: dynamicSize(5),
        // marginLeft: dynamicSize(5),
        fontSize: getFontSize(14),
        fontFamily: fontFamily(),
        flexDirection: 'row',
        // justifyContent:'center',
        alignItems: 'center',
        borderWidth: dynamicSize(1),
        borderColor: '#C3C3C3',
        // width: dynamicSize(0),
        //height:70,
        paddingHorizontal: 15,
        // backgroundColor:'#fff'
    },
    buttonView: {
        // width: dynamicSize(null),
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: dynamicSize(15),
        //marginLeft: dynamicSize(5),
        // marginLeft: 40,
        // marginRight: 40,
        backgroundColor: '#F49930',
        padding: dynamicSize(15),
        // borderRadius: 30,
    },
    uploadPic: {
        backgroundColor: '#F5F5F5',
        // width: dynamicSize(null),
        height: dynamicSize(100),
        borderWidth: dynamicSize(1),
        borderColor: '#C3C3C3',
        marginBottom: dynamicSize(10),
        alignItems: 'center',
        justifyContent: 'center'
    },
    accomodationView: { alignItems: 'center', borderTopColor: "#A2A8A2", borderTopWidth: 0, flexDirection: 'row', marginTop: dynamicSize(5) },
    boldText: { fontSize: getFontSize(14), fontFamily: fontFamily('bold'), color: "#7a7a7a" }
});