/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, StatusBar, TouchableOpacity, FlatList, Image } from 'react-native';
import { dynamicSize, getFontSize, fontFamily } from '../../utils/responsive';
const check = require("../../assets/round-check.png");
const uncheck = require("../../assets/round-uncheck.png");

export default class DealListing extends Component {

    constructor() {
        super()
        this.state = {
            activeTab: 'active',
            activeList: [{}, {}, {}, {}],
            draftsList: [{}, {}, {}, {}],
            suspendedList: [{}, {}, {}, {}],
            showSelction: false

        }
    }


    _switchTab(type) {
        if (type == "active") {
            this.setState({
                activeTab: "active"
            })
        }
        else if (type == "drafts") {
            this.setState({
                activeTab: "drafts"
            })
        }
        else {
            this.setState({
                activeTab: "suspended"
            })
        }
    }


    _multiSelectDrafts(item, index, check) {
        var data = this.state.draftsList;
        var empty = false;
        var nonempty = false;
        if (check == "child") {
            data[index].selected = !data[index].selected;
            for (let i = 0; i < data.length; i++) {
                if (!data[i].selected) {
                    empty = true
                }
                else {
                    nonempty = true
                }
            }
            // alert(empty + "  " + nonempty)
            if ((empty == true) && (nonempty == false)) {
                // alert("close")
                this.setState({ showSelction: false })
            }
        }
        else {
            for (let i = 0; i < data.length; i++) {

                // alert(i + " " + index)
                if (i == index) {
                    data[i].selected = true
                }
                else {
                    data[i].selected = false
                }
            }
            this.setState({ draftsList: data, showSelction: true })
        }
        this.setState({ draftsList: data })
    }


    _showActiveList(item, index) {
        return (
            <TouchableOpacity style={{ flexDirection: "row", alignItems: "flex-start", paddingHorizontal: dynamicSize(20), paddingVertical: dynamicSize(10), borderBottomWidth: dynamicSize(0.5), borderBottomColor: "#e7e7e7" }}>
                <View style={{ height: dynamicSize(30), width: dynamicSize(30), borderWidth: dynamicSize(1), borderColor: "#e7e7e7" }}>
                    <Image style={{ flex: 1 }} source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT31HrihBb3Mw8IQWbBrnmlpRxwmUnJLtdcIMg70UG5uyZDiG4L" }} />
                </View>
                <View style={{ marginLeft: dynamicSize(13), flex: 1 }}>
                    <Text style={{ fontFamily: fontFamily(), fontSize: getFontSize(11), color: "#7a7a7a", width: "90%" }}>Dominos - Regular pizza free with Medium Pizza</Text>
                    <Text style={{ fontFamily: fontFamily(), fontSize: getFontSize(10), color: "#7a7a7a", marginTop: dynamicSize(5) }}>Expires in : 03 months</Text>
                </View>
            </TouchableOpacity>
        )
    }

    _showDraftList(item, index) {
        return (
            <TouchableOpacity onLongPress={() => this._multiSelectDrafts(item, index)} style={{ flexDirection: "row", alignItems: "flex-start", paddingHorizontal: dynamicSize(20), paddingVertical: dynamicSize(10), borderBottomWidth: dynamicSize(0.5), borderBottomColor: "#e7e7e7" }}>
                <View style={{ height: dynamicSize(30), width: dynamicSize(30), borderWidth: dynamicSize(1), borderColor: "#e7e7e7" }}>
                    <Image style={{ flex: 1 }} source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT31HrihBb3Mw8IQWbBrnmlpRxwmUnJLtdcIMg70UG5uyZDiG4L" }} />
                </View>
                <View style={{ marginLeft: dynamicSize(13), flex: 1, width: "100%" }}>
                    <Text style={{ fontFamily: fontFamily(), fontSize: getFontSize(11), color: "#7a7a7a" }}>Dominos - Regular pizza free with Medium Pizza</Text>
                    <Text style={{ fontFamily: fontFamily(), fontSize: getFontSize(10), color: "#7a7a7a", marginTop: dynamicSize(5) }}>Saved : 18/07/2018</Text>
                </View>
                {this.state.showSelction ?
                    <TouchableOpacity onPress={() => this._multiSelectDrafts(item, index, "child")}>
                        <Image source={item.selected ? check : uncheck} />
                    </TouchableOpacity>
                    :
                    null
                }
            </TouchableOpacity>
        )
    }

    _showSuspendedList(item, index) {
        return (
            <Text style={{ textAlign: "center" }}>Suspended</Text>
        )
    }


    render() {
        return (
            <View style={styles.container}>

                <View style={{ borderColor: "#e7e7e7", marginBottom: dynamicSize(10), flexDirection: "row", justifyContent: "space-between", borderWidth: dynamicSize(0.3), height: dynamicSize(45), paddingHorizontal: dynamicSize(25) }}>
                    <TouchableOpacity onPress={() => this._switchTab("active")} style={{ flex: 1, justifyContent: "center", alignItems: "center", borderBottomWidth: this.state.activeTab == "active" ? dynamicSize(3) : 0, borderBottomColor: "#56B24D" }}>
                        <Text style={{ fontFamily: fontFamily("semibold"), fontSize: getFontSize(12), color: this.state.activeTab == "active" ? "#56B24D" : "#7a7a7a" }}>Active</Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => this._switchTab("drafts")} style={{ flex: 1, justifyContent: "center", alignItems: "center", borderBottomWidth: this.state.activeTab == "drafts" ? dynamicSize(3) : 0, borderBottomColor: "#56B24D" }}>
                        <Text style={{ fontFamily: fontFamily("semibold"), fontSize: getFontSize(12), color: this.state.activeTab == "drafts" ? "#56B24D" : "#7a7a7a" }}>Drafts</Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => this._switchTab("suspended")} style={{ flex: 1, justifyContent: "center", alignItems: "center", borderBottomWidth: this.state.activeTab == "suspended" ? dynamicSize(3) : 0, borderBottomColor: "#56B24D" }}>
                        <Text style={{ fontFamily: fontFamily("semibold"), fontSize: getFontSize(12), color: this.state.activeTab == "suspended" ? "#56B24D" : "#7a7a7a" }}>Suspended</Text>
                    </TouchableOpacity>
                </View>

                <FlatList
                    data={this.state.activeTab == "active" ? this.state.activeList : this.state.activeTab == "drafts" ? this.state.draftsList : this.state.suspendedList}
                    renderItem={({ item, index }) => this.state.activeTab == "active" ? this._showActiveList(item, index) : this.state.activeTab == "drafts" ? this._showDraftList(item, index) : this._showSuspendedList(item, index)}
                    keyExtractor={(item, index) => index}
                    extraData={this.state}

                />


            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "white",
    },
    welcome: {
        fontSize: 20,
        textAlign: 'center',
        margin: 10,
    },
    instructions: {
        textAlign: 'center',
        color: '#333333',
        marginBottom: 5,
    },
});
