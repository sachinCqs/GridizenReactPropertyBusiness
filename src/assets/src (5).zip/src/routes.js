import React, { Component } from 'react';
import { AsyncStorage, Alert, Dimensions, TouchableOpacity, Text, View, ImageBackground, TextInput, Image } from 'react-native';
import { createStackNavigator, createDrawerNavigator, createSwitchNavigator } from 'react-navigation';
import Login from './screens/pre-login screens/login';
import SignUp from './screens/pre-login screens/signup';
import Verification from './screens/pre-login screens/verification';
import ForgorPassword from './screens/pre-login screens/forgot_password';
import ResetPassword from './screens/pre-login screens/reset_password';
import { dynamicSize, getFontSize, fontFamily, themeColor } from './utils/responsive';
import { NavigationActions, StackActions } from 'react-navigation';
import TabNavigator from './screens/bottomTabs/tabnavigator';
import DealListing from './screens/bottomTabs/DealListing';
import AddDeal from './screens/bottomTabs/addDeal';
const { height, width } = Dimensions.get('window');

const stack = createStackNavigator({

    Login: {
        screen: Login,
        navigationOptions: () => ({
            header: null
        })
    },
    SignUp: {
        screen: SignUp,
        navigationOptions: () => ({
            header: null
        })
    },
    Verification: {
        screen: Verification,
        navigationOptions: () => ({
            header: null
        })
    },
    ForgorPassword: {
        screen: ForgorPassword,
        navigationOptions: () => ({
            header: null
        })
    },
    ResetPassword: {
        screen: ResetPassword,
        navigationOptions: () => ({
            header: null
        })
    },
    TabNavigator: {
        screen: TabNavigator,
        navigationOptions: () => ({
            header: null
        })
    },
    DealListing: {
        screen: DealListing,
        navigationOptions: () => ({
            header: null
        })
    },
    AddDeal: {
        screen: AddDeal,
        navigationOptions: () => ({
            title: "Add a Deal",
            headerTitleStyle: {
                fontFamily: fontFamily(),
            }
        })
    }
}
    , {
        initialRouteName: "AddDeal",
        navigationOptions: {
            headerTintColor: '#7a7a7a',
            headerStyle: {
                borderTopWidth: 0.5,

                borderTopColor: '#e7e7e7',
                borderBottomColor: 'white',

            },



        },
    }
)


const mainRoute = createStackNavigator({

    Login: {
        screen: Login,
        navigationOptions: () => ({
            header: null
        })
    },
    SignUp: {
        screen: SignUp,
        navigationOptions: () => ({
            header: null
        })
    },
    Verification: {
        screen: Verification,
        navigationOptions: () => ({
            header: null
        })
    },
    ForgorPassword: {
        screen: ForgorPassword,
        navigationOptions: () => ({
            header: null
        })
    },
    ResetPassword: {
        screen: ResetPassword,
        navigationOptions: () => ({
            header: null
        })
    },
    TabNavigator: {
        screen: TabNavigator,
        navigationOptions: () => ({
            header: null
        })
    },
    DealListing: {
        screen: DealListing,
        navigationOptions: () => ({
            title: "Deals Listing",
            headerTitleStyle: {
                fontFamily: fontFamily(),
            }
        })
    },
    AddDeal: {
        screen: AddDeal,
        navigationOptions: () => ({
            title: "Add a Deal",
            headerTitleStyle: {
                fontFamily: fontFamily(),
            }
        })
    }

}
    , {
        initialRouteName: "AddDeal",
        navigationOptions: {
            headerTintColor: '#7a7a7a',
            headerStyle: {
                borderTopWidth: 0.5,

                borderTopColor: '#e7e7e7',
                borderBottomColor: 'white',

            },
            headerTitleStyle: {
                fontFamily: fontFamily()
            }

        },
    }
)
// const Drawer = createDrawerNavigator({
//     myProfile: {
//         screen: myProfile,
//         drawerLabel: 'My profile',
//     }
// });

class HandleNavigation extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
        this.checkAuth()
    }

    checkAuth = () => {
        AsyncStorage.getItem('headerData').then(data => {
            if (data != null) {
                this.props.navigation.navigate('mainRoute')
            }
            else this.props.navigation.navigate('stack')
        })
    }
    render() {
        return (
            <View></View>
        )
    }
}

export const Navigation = createSwitchNavigator({
    HandleNavigation: HandleNavigation,
    stack: { screen: stack },
    mainRoute: { screen: mainRoute }
});
export default Navigation;