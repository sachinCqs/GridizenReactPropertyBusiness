import React, { Component } from 'react';
import { Platform, Image, AsyncStorage, ScrollView, RefreshControl, TouchableWithoutFeedback, Dimensions, FlatList, TouchableOpacity, StyleSheet, Text, View, ImageBackground, TextInput } from 'react-native';
import { dynamicSize, getFontSize, dateConverterMMDDYYYY, themeColor, fontFamily } from '../utils/responsive';
const { height, width } = Dimensions.get('window');
import { ErrModal, Toast, Spinner } from '../components/toast'
import { FloatButton } from '../components/button'
import { NodeAPI } from '../services/webservice'
export default class Dashboard extends Component {
    constructor(props) {
        super(props)
        this.state = {
            // propertyList: [
            //     {
            //         rent: 35000,
            //         address1: 'Rwa Nizamuddin west',
            //         address2: 'Delhi',
            //         bedrooms: '1 BHK',
            //         furnishedType: 'Semifurnished',
            //         contactType: 'Dealer',
            //         contactPerson: 'Manish',
            //         like: false,
            //         postedOn: new Date().getTime(),
            //         seen: false,
            //         image: 'https://imagejournal.org/wp-content/uploads/bb-plugin/cache/23466317216_b99485ba14_o-panorama.jpg'
            //     },
            //     {
            //         rent: 3000,
            //         address1: 'Govind puri',
            //         address2: 'kalka ji',
            //         bedrooms: '3 BHK',
            //         furnishedType: 'Furnished',
            //         contactType: 'Owner',
            //         contactPerson: 'Suresh',
            //         like: true,
            //         postedOn: new Date().getTime(),
            //         seen: true,
            //         image: 'https://www.gettyimages.ca/gi-resources/images/Homepage/Hero/UK/CMS_Creative_164657191_Kingfisher.jpg'
            //     }
            // ],
            propertyList: [],
            headerData: '',
            spinnerVisible: false,
            showToast: false,
            alertMessage: "",
            refreshing: false
        }
    }
    componentWillMount() {
        AsyncStorage.getItem("headerData").then(data => {
            let paramData = JSON.parse(data)
            this.setState({
                headerData: paramData,
                spinnerVisible: true
            })
            this.hitGetAllListApi(paramData)
            // getAllProperties.json/:page/:pageSize/:sortBy/:sortType/:search?

        })
    }
    updateList = () => {
        this.hitGetAllListApi(this.state.headerData)
    }
    hitGetAllListApi(paramData) {
        // this.setState({ refreshing: true })
        return NodeAPI({}, "getAllProperties.json/0/200", 'GET', paramData.token, paramData.userid)
            .then(responseJson => {
                this.setState({ spinnerVisible: false, refreshing: false })
                if (responseJson.response_code === 'success') {
                    // alert(JSON.stringify(responseJson.areaunits.length))
                    console.log(JSON.stringify(responseJson))
                    var arr = responseJson.properties
                    for (var i = 0; i < responseJson.properties.length; i++) {
                        arr[i].like = false
                    }
                    this.setState({ propertyList: arr })
                } else {
                    // setTimeout(() => {
                    //     alert(responseJson.msg)
                    // }, 300)
                    this.setState({ showToast: true, alertMessage: responseJson.msg })
                    setTimeout(() => {
                        this.setState({ showToast: false })

                    }, 3000);
                }
                //alert(JSON.stringify(response));
            })

    }

    onHeartPress(index) {
        var arr = this.state.propertyList
        arr[index].like = !arr[index].like
        this.setState({ propertyList: arr })
    }
    checkImage(item) {
        return item.type == 'I';
    }
    showList(item, index) {
        var count = item.propertyPhotos.filter(this.checkImage).length

        return (
            <TouchableWithoutFeedback onPress={() => this.props.navigation.navigate('PropertyDetails', { data: item, updateList: () => this.updateList() })}>
                <View style={styles.propertyListRow}>
                    <View style={styles.imageView}>
                        <ImageBackground source={{ uri: item.propertyPhotos[0] ? item.propertyPhotos[0].image : '' }}
                            style={styles.propertyImage} />

                        <View style={styles.propertyImageOpacity} />
                        {/* <View style={styles.dateView}>
                        <Text style={styles.dateText}>Posted On {dateConverterMMDDYYYY(new Date(item.postedOn))}</Text>
                    </View> */}
                        <TouchableOpacity onPress={() => this.onHeartPress(index)}
                            style={styles.likeView}>
                            <Image resizeMode='contain'
                                source={item.like ? require('../assets/propertyList/heart-active.png') : require('../assets/propertyList/heart-white.png')} />
                        </TouchableOpacity>

                        <TouchableOpacity
                            style={{ position: 'absolute', backgroundColor: '#000000', paddingHorizontal: dynamicSize(2), bottom: dynamicSize(10), right: dynamicSize(10), flexDirection: 'row', alignItems: 'center' }}>
                            <Text style={{ color: 'white', fontSize: getFontSize(11), fontFamily: fontFamily(), marginRight: dynamicSize(2) }}>{count}</Text>
                            <Image source={require('../assets/propertyList/cam-white.png')} />
                        </TouchableOpacity>

                    </View>
                    <View style={styles.detailView}>
                        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                            <Text style={styles.rentText}>£ {item.expectedRent.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ' PCM'}</Text>
                            <View style={{ flexDirection: 'row' }}>
                                <Text style={{ color: item.status == 1 ? themeColor : 'red', marginRight: dynamicSize(5) }}>{item.status == 1 ? 'Active' : item.status == 2 ? 'In-Active' : ''}</Text>
                                <Image source={require('../assets/threeDot.png')} />
                            </View>
                        </View>
                        <Text numberOfLines={1}
                            style={styles.address1Text}>{item.bedroom + ' Bed ' + item.propertyType + ' for rent'}</Text>
                        <Text numberOfLines={1}
                            style={styles.address2Text}>{item.address}</Text>
                        <Text numberOfLines={1}
                            style={styles.dateText}>{'Posted on ' + dateConverterMMDDYYYY(new Date(item.createdAt))}</Text>

                        {/* <Text numberOfLines={1}
                        style={styles.BHKText}>{item.bedrooms + ' ' + item.furnishedType}</Text> */}
                        <View style={{ marginTop: dynamicSize(5), flexDirection: 'row', justifyContent: 'space-between' }}>
                            <View
                                style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <Image source={require('../assets/propertyList/bed-sml-icn.png')} />
                                <Text style={{ color: 'grey', fontSize: getFontSize(14), fontFamily: fontFamily('bold'), marginLeft: dynamicSize(2) }}>{item.bedroom}</Text>

                            </View>
                            <View
                                style={{ flexDirection: 'row', alignItems: 'center', marginRight: dynamicSize(10) }}>
                                <Image source={require('../assets/propertyList/bath-icn.png')} />
                                <Text style={{ color: 'grey', fontSize: getFontSize(14), fontFamily: fontFamily('bold'), marginLeft: dynamicSize(2) }}>{item.bathroom}</Text>

                            </View>
                            <View
                                style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <Image source={require('../assets/propertyList/sofa.png')} />
                                <Text style={{ color: 'grey', fontSize: getFontSize(14), fontFamily: fontFamily('bold'), marginLeft: dynamicSize(2) }}>{item.reception}</Text>

                            </View>
                            <View
                                style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <Text style={{ color: 'grey', fontSize: getFontSize(11), fontFamily: fontFamily(), marginRight: dynamicSize(10) }}>{item.build_up_area + " " + item.build_up_area_unit}</Text>

                            </View>
                        </View>
                    </View>
                </View>
            </TouchableWithoutFeedback>
        )
    }
    refresh() {
        this.setState({ refreshing: true })
        this.hitGetAllListApi(this.state.headerData)
    }
    render() {
        return (
            <View style={styles.fullView}>
                <Spinner visible={this.state.spinnerVisible} />
                <Toast visible={this.state.showToast} message={this.state.alertMessage} />
                <Text style={{ fontFamily: fontFamily("bold"), marginLeft: dynamicSize(10), marginTop: dynamicSize(5), fontSize: getFontSize(14) }}>{this.state.propertyList.length <= 1 ? this.state.propertyList.length + " property found" : this.state.propertyList.length + " properties found"}</Text>
                {/* <View style={{width:width, height: dynamicSize(5),
                        backgroundColor:'#dcdcdc',marginVertical:dynamicSize(2)}}/> */}
                <ScrollView
                    style={{}}
                    refreshControl={
                        <RefreshControl
                            refreshing={this.state.refreshing}
                            onRefresh={() => this.refresh()}
                            progressViewOffset={dynamicSize(10)}
                            colors={[themeColor]}
                            progressBackgroundColor="white"
                        />
                    }
                >
                    <FlatList
                        data={this.state.propertyList}
                        renderItem={({ item, index }) => this.showList(item, index)}
                        keyExtractor={(item, index) => index}
                        showsVerticalScrollIndicator={false}
                        scrollEnabled={true}
                        marginTop={dynamicSize(5)}
                        marginBottom={dynamicSize(10)}
                        extraData={this.state}
                        ref={(scroller) => { this.scroller = scroller }}
                    />
                    <View style={{ height: dynamicSize(60) }} />
                </ScrollView>

                <FloatButton onPress={() => this.props.navigation.navigate('Step1')} />
            </View>
            // <Image resizeMode="stretch" source={require('../assets/icons/businessDashboard.jpg')} style={{flex:1}}/>
        )
    }
}

const styles = StyleSheet.create({
    fullView: {
        flex: 1,
        backgroundColor: '#fff'

    },
    propertyListRow: {
        width: width,
        backgroundColor: '#fff',
        flexDirection: 'row',


        borderBottomWidth: dynamicSize(5),
        borderBottomColor: '#dcdcdc'
    },
    imageView: {
        width: (width / 2) - dynamicSize(40),
        height: (width / 2) - dynamicSize(80),
        padding: dynamicSize(10),


    },
    detailView: {
        width: (width / 2) + dynamicSize(40), paddingVertical: dynamicSize(8),


    },
    propertyImage: {
        width: (width / 2) - dynamicSize(60),
        height: (width / 2) - dynamicSize(100),


    },
    propertyImageOpacity: {
        width: (width / 2) - dynamicSize(60),
        height: (width / 2) - dynamicSize(100),
        opacity: 0.4,
        backgroundColor: '#000000', position: 'absolute',
        left: dynamicSize(10), top: dynamicSize(10),

    },
    dateView: { position: 'absolute', bottom: 0, right: 0, backgroundColor: 'red', justifyContent: 'flex-end' },
    //dateText: { fontSize: getFontSize(10), color: '#fff', marginHorizontal: dynamicSize(5) },
    likeView: { position: 'absolute', top: dynamicSize(15), left: dynamicSize(15) },
    seenView: { backgroundColor: '#00000098', padding: dynamicSize(2), paddingHorizontal: dynamicSize(5), position: 'absolute', right: 0, top: 0 },

    rentText: { color: 'grey', fontSize: getFontSize(16), fontFamily: fontFamily('bold') },
    address1Text: { fontSize: getFontSize(11), color: themeColor, fontFamily: fontFamily('bold') },
    address2Text: { fontSize: getFontSize(11), fontFamily: fontFamily() },
    dateText: { fontSize: getFontSize(10), color: '#a2a8a2', fontFamily: fontFamily(), marginTop: dynamicSize(3) },
    BHKText: { fontSize: getFontSize(13), color: '#3c3c3c', marginTop: dynamicSize(8) }
});