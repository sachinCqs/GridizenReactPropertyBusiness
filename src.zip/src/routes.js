import { createStackNavigator, createSwitchNavigator, createDrawerNavigator } from 'react-navigation';
import Login from './screens/login';
import React, { Component } from 'react';
import { AsyncStorage, Text, View, Dimensions, ImageBackground, Image, TouchableOpacity } from 'react-native';
import { dynamicSize, getFontSize, fontFamily, themeColor } from './utils/responsive';
const { height, width } = Dimensions.get('window');

import SignUp from './screens/signup';
import UserType from './screens/userType';
import Demo from './screens/demo';
import Verification from './screens/verification';
import Home from './screens/home';
import ForgorPassword from './screens/forgot_password';
import ResetPassword from './screens/reset_password';
import Step3 from './screens/step_3';
import ImagesShow from './screens/ImagesShow';
import Step1 from './screens/step1'
import Step2 from './screens/step2'
import PropertyList from './screens/propertyList'
import GoogleAutoCompleteList from './List_Modal/googleAutoCompleteList';
import PropertyDetails from './screens/propertyDetails'
import PropertyReview from './screens/propertyReview'
import { NavigationActions, StackActions } from 'react-navigation';
import Inventory from './screens/inventory'
import Appointment from './screens/appointment'

const stack = createStackNavigator({

    Login: {
        screen: Login,
        navigationOptions: () => ({
            header: null
        })
    },
    GoogleAutoCompleteList: {
        screen: GoogleAutoCompleteList,
    },
    Step1: {
        screen: Step1,
        navigationOptions: () => ({
            title: "Add Property",
            headerTintColor: themeColor,
            headerTitleStyle: {
                width: '100%',
                textAlign: 'center'
            },
            headerRight: (<View></View>),
        })
    },
    PropertyList: {
        screen: PropertyList,
        navigationOptions: ({ navigation }) => ({
            title: "Property List",
            headerTintColor: themeColor,
            headerTitleStyle: {
                width: '100%',
                textAlign: 'center'
            },
            headerBackTitle: null,
            headerRight: (
                <TouchableOpacity onPress={() => {
                    AsyncStorage.removeItem("headerData"),
                        resetAction = StackActions.reset({
                            index: 0,
                            actions: [NavigationActions.navigate({ routeName: 'Login' })],
                        });
                    navigation.dispatch(resetAction);
                }}>
                    <Image
                        style={{ height: dynamicSize(20), tintColor: themeColor, width: dynamicSize(20), marginRight: dynamicSize(20) }}
                        source={require("./assets/logout.png")} />
                </TouchableOpacity>

            ),
        })
    },
    Step2: {
        screen: Step2,
        navigationOptions: () => ({
            title: "Add Property",
            headerTintColor: themeColor,
            headerTitleStyle: {
                width: '100%',
                textAlign: 'center'
            },
            headerRight: (<View></View>),
        })
    },
    PropertyReview: {
        screen: PropertyReview,
        navigationOptions: () => ({
            title: "Property Review",
            headerTintColor: themeColor,
            headerTitleStyle: {
                width: '100%',
                textAlign: 'center'
            },
            headerRight: (<View></View>),
        })
    },
    SignUp: {
        screen: SignUp,
        navigationOptions: () => ({
            header: null
        })
    },
    UserType: {
        screen: UserType,
        navigationOptions: () => ({
            header: null
        })
    },
    Demo: {
        screen: Demo,

    },
    Verification: {
        screen: Verification,
        navigationOptions: () => ({
            header: null
        })
    },
    Home: {
        screen: Home,
        navigationOptions: ({ navigation }) => ({
            title: "HOME",
            headerBackTitle: null,
            headerRight: (
                <TouchableOpacity onPress={() => {
                    AsyncStorage.removeItem("headerData"),
                        resetAction = StackActions.reset({
                            index: 0,
                            actions: [NavigationActions.navigate({ routeName: 'Login' })],
                        });
                    navigation.dispatch(resetAction);
                }}>
                    <Image
                        style={{ height: dynamicSize(20), width: dynamicSize(20), marginRight: dynamicSize(20) }}
                        source={require("./assets/logout.png")} />
                </TouchableOpacity>

            ),
        })
    },
    ForgorPassword: {
        screen: ForgorPassword,
        navigationOptions: () => ({
            header: null
        })
    },
    ResetPassword: {
        screen: ResetPassword,
        navigationOptions: () => ({
            header: null
        })
    },
    Step3: {
        screen: Step3,
        navigationOptions: () => ({
            title: "Add Property",
            headerTintColor: themeColor,
            headerTitleStyle: {
                width: '100%',
                textAlign: 'center'
            },
            headerRight: (<View></View>),
        })
    },
    Appointment: {
        screen: Appointment,
        headerBackTitle:null,
        navigationOptions: () => ({
            title: "Appointment",
            headerTintColor: themeColor,
            headerTitleStyle: {
                width: '100%',
                textAlign: 'center'
            },
            headerRight: (<View></View>),
        })
    },
    Inventory: {
        screen: Inventory,
        navigationOptions: () => ({
            title: "Add Inventory",
            headerTintColor: themeColor,
            headerTitleStyle: {
                width: '100%',
                textAlign: 'center'
            },
            headerRight: (<View></View>),
        })
    },
    PropertyDetails: {
        screen: PropertyDetails,
        navigationOptions: () => ({
            title: "Property Details",
            headerTintColor: themeColor,
            headerTitleStyle: {
                width: '100%',
                textAlign: 'center'
            },
            headerRight: (<View></View>),
        })

    },
    ImagesShow: {
        screen: ImagesShow,
        navigationOptions: () => ({
            header: null
        })
    }

}
    , {
        initialRouteName: "Login"
    }
)


const mainRoute = createStackNavigator({

    Login: {
        screen: Login,
        navigationOptions: () => ({
            header: null
        })
    },
    GoogleAutoCompleteList: {
        screen: GoogleAutoCompleteList,
    },
    Step1: {
        screen: Step1,
        navigationOptions: () => ({
            title: "Add Property",
            headerTintColor: themeColor,
            headerTitleStyle: {
                width: '100%',
                textAlign: 'center',


            },
            headerRight: (<View></View>),

            //headerTitleStyle: { width:width-70,textAlign:'center',color:themeColor },
        })
    },
    PropertyList: {
        screen: PropertyList,
        navigationOptions: ({ navigation }) => ({
            title: "Property List",
            headerTintColor: themeColor,
            headerTitleStyle: {
                width: '100%',
                textAlign: 'center',

            },
            tintColor: themeColor,
            //headerLeft: (<View></View>),

            headerBackTitle: null,
            headerRight: (
                <TouchableOpacity onPress={() => {
                    AsyncStorage.removeItem("headerData"),
                        resetAction = StackActions.reset({
                            index: 0,
                            actions: [NavigationActions.navigate({ routeName: 'Login' })],
                        });
                    navigation.dispatch(resetAction);
                }}>
                    <Image
                        style={{ height: dynamicSize(20), tintColor: themeColor, width: dynamicSize(20), marginRight: dynamicSize(20) }}
                        source={require("./assets/logout.png")} />
                </TouchableOpacity>

            ),
        })
    },
    PropertyReview: {
        screen: PropertyReview,
        navigationOptions: () => ({
            title: "Property Review",
            headerTintColor: themeColor,
            headerTitleStyle: {
                width: '100%',
                textAlign: 'center'
            },
            headerRight: (<View></View>),
        })
    },
    Step2: {
        screen: Step2,
        navigationOptions: () => ({
            title: "Add Property",
            headerTintColor: themeColor,
            headerTitleStyle: {
                width: '100%',
                textAlign: 'center'
            },
            headerRight: (<View></View>),
        })
    },
    Appointment: {
        screen: Appointment,
        //headerBackTitle:null,
        navigationOptions: () => ({
            title: "Appointment",
            headerTintColor: themeColor,
            headerTitleStyle: {
                width: '100%',
                textAlign: 'center'
            },
            headerRight: (<View></View>),
            headerLeft: (<View></View>),
        })
    },
    Inventory: {
        screen: Inventory,
        navigationOptions: () => ({
            title: "Add Inventory",
            headerTintColor: themeColor,
            headerTitleStyle: {
                width: '100%',
                textAlign: 'center'
            },
            headerRight: (<View></View>),
        })
    },
    PropertyDetails: {
        screen: PropertyDetails,
        // navigationOptions: () => ({
        //     title: "Property Details",
        //     headerTintColor: themeColor,
        //     headerTitleStyle: {
        //         width: '100%',
        //         textAlign: 'center'
        //     },
        //     headerRight: (<View></View>),
        // })

    },
    SignUp: {
        screen: SignUp,
        navigationOptions: () => ({
            header: null
        })
    },
    UserType: {
        screen: UserType,
        navigationOptions: () => ({
            header: null
        })
    },
    Demo: {
        screen: Demo,

    },
    Verification: {
        screen: Verification,
        navigationOptions: () => ({
            header: null
        })
    },
    Home: {
        screen: Home,
        navigationOptions: ({ navigation }) => ({
            title: "HOME",
            headerBackTitle: null,
            headerRight: (
                <TouchableOpacity onPress={() => {
                    AsyncStorage.removeItem("headerData"),
                        resetAction = StackActions.reset({
                            index: 0,
                            actions: [NavigationActions.navigate({ routeName: 'Login' })],
                        });
                    navigation.dispatch(resetAction);
                }}>
                    <Image
                        style={{ height: dynamicSize(20), width: dynamicSize(20), marginRight: dynamicSize(20) }}
                        source={require("./assets/logout.png")} />
                </TouchableOpacity>

            ),
        })
    },
    ForgorPassword: {
        screen: ForgorPassword,
        navigationOptions: () => ({
            header: null
        })
    },
    ResetPassword: {
        screen: ResetPassword,
        navigationOptions: () => ({
            header: null
        })
    },
    Step3: {
        screen: Step3,
        navigationOptions: () => ({
            title: "Add Property",
            headerTintColor: themeColor,
            headerTitleStyle: {
                width: '100%',
                textAlign: 'center'
            },
            headerRight: (<View></View>),
        })

    },
    ImagesShow: {
        screen: ImagesShow,
        navigationOptions: () => ({
            header: null
        })
    }

}
    , {
        initialRouteName: "PropertyList"
    }
)

// const Drawer = createDrawerNavigator({
//     myProfile: {
//         screen: myProfile,
//         drawerLabel: 'My profile',
//     }
// });


class HandleNavigation extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
        this.checkAuth()
    }

    checkAuth = () => {

        AsyncStorage.getItem('headerData').then(data => {
            if (data != null) {
                this.props.navigation.navigate('mainRoute')
            }
            else this.props.navigation.navigate('stack')
        })
    }

    render() {
        return (
            <View></View>
        )
    }
}

export const Navigation = createSwitchNavigator({
    HandleNavigation: HandleNavigation,
    stack: { screen: stack },
    mainRoute: { screen: mainRoute }
});
export default Navigation;
//export default token == '' ? stack : mainRoute;